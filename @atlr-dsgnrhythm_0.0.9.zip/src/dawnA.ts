// Copyright © 2022 Rhythm® Color. All rights reserved.
export const dawnA = {
  dawnA1: 'hsla(0, 0%, 0%, 0.012)',
  dawnA2: 'hsla(0, 0%, 0%, 0.027)',
  dawnA3: 'hsla(0, 0%, 0%, 0.047)',
  dawnA4: 'hsla(0, 0%, 0%, 0.071)',
  dawnA5: 'hsla(0, 0%, 0%, 0.090)',
  dawnA6: 'hsla(0, 0%, 0%, 0.114)',
  dawnA7: 'hsla(0, 0%, 0%, 0.141)',
  dawnA8: 'hsla(0, 0%, 0%, 0.220)',
  dawnA9: 'hsla(0, 0%, 0%, 0.439)',
  dawnA10: 'hsla(0, 0%, 0%, 0.478)',
  dawnA11: 'hsla(0, 0%, 0%, 0.565)',
  dawnA12: 'hsla(0, 0%, 0%, 0.910)',
};
