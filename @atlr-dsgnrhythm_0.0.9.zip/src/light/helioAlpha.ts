export const helioAlpha = {
    helioA1: 'hsla(111, 100%, 97%, 0.031)',
    helioA2: 'hsla(113, 100%, 88%, 0.061)',
    helioA3: 'hsla(112, 100%, 80%, 0.087)',
    helioA4: 'hsla(113, 100%, 74%, 0.113)',
    helioA5: 'hsla(113, 91%, 68%, 0.148)',
    helioA6: 'hsla(126, 46%, 53%, 0.191)',
    helioA7: 'hsla(139, 39%, 38%, 0.273)',
    helioA8: 'hsla(152, 36%, 22%, 0.416)',
    helioA9: 'hsla(165, 35%, 7%, 0.700)',
};
