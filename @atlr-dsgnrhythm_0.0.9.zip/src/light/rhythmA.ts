export const rhythmA = {
  rhythmA1: 'hsla(300, 89.3%, 18.3%, 0.012)',
  rhythmA2: 'hsla(300, 78.1%, 9.0%, 0.028)',
  rhythmA3: 'hsla(300, 99.5%, 7.7%, 0.051)',
  rhythmA4: 'hsla(270, 90.5%, 6.1%, 0.071)',
  rhythmA5: 'hsla(270, 83.0%, 5.2%, 0.091)',
  rhythmA6: 'hsla(300, 93.5%, 3.7%, 0.114)',
  rhythmA7: 'hsla(270, 82.6%, 3.3%, 0.142)',
  rhythmA8: 'hsla(255, 95.2%, 3.7%, 0.220)',
  rhythmA9: 'hsla(255, 94.8%, 3.7%, 0.444)',
  rhythmA10: 'hsla(253, 96.5%, 3.8%, 0.483)',
  rhythmA11: 'hsla(247, 97.9%, 3.2%, 0.569)',
  rhythmA12: 'hsla(261, 98.7%, 3.0%, 0.918)',
};
