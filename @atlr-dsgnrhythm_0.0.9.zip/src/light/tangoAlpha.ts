export const tangoAlpha = {
    tangoA1: 'hsla(24, 100%, 97%, 0.031)',
    tangoA2: 'hsla(24, 100%, 87%, 0.061)',
    tangoA3: 'hsla(22, 100%, 78%, 0.087)',
    tangoA4: 'hsla(20, 100%, 71%, 0.113)',
    tangoA5: 'hsla(19, 99%, 67%, 0.148)',
    tangoA6: 'hsla(11, 67%, 53%, 0.191)',
    tangoA7: 'hsla(3, 72%, 40%, 0.273)',
    tangoA8: 'hsla(352, 85%, 29%, 0.416)',
    tangoA9: 'hsla(341, 100%, 18%, 0.700)',
};
