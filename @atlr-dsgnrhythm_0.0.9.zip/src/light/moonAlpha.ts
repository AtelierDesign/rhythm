export const moonAlpha = {
    moonA1: 'hsla(218, 90%, 96%, 0.012)',
    moonA2: 'hsla(236, 84%, 93%, 0.028)',
    moonA3: 'hsla(252, 79%, 89%, 0.051)',
    moonA4: 'hsla(268, 76%, 85%, 0.071)',
    moonA5: 'hsla(286, 73%, 81%, 0.091)',
    moonA6: 'hsla(299, 43%, 71%, 0.114)',
    moonA7: 'hsla(310, 28%, 61%, 0.142)',
    moonA8: 'hsla(325, 19%, 51%, 0.444)',
    moonA9: 'hsla(336, 19%, 41%, 0.700)',
};
