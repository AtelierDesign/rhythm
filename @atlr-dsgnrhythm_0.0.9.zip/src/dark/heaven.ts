export const heavenDark = {
    heaven1: 'rgba(35, 34, 59, 1)',
    heaven2: 'rgba(68, 65, 108, 1)',
    heaven3: 'rgba(103, 99, 154, 1)',
    heaven4: 'rgba(140, 136, 197, 1)',
    heaven5: 'rgba(180, 176, 236, 1)',
    heaven6: 'rgba(193, 189, 246, 1)',
    heaven7: 'rgba(208, 205, 253, 1)',
    heaven8: 'rgba(227, 225, 255, 1)',
    heaven9: 'rgba(249, 249, 255, 1)',
};
