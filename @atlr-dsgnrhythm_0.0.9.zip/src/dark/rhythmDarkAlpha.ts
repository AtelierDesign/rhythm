export const rhythmDarkAlpha = {
  rhythmA1: 'hsla(0, 0%, 0%, 0)',
  rhythmA2: 'hsla(240, 76.7%, 91.2%, 0.031)',
  rhythmA3: 'hsla(240, 86.0%, 95.8%, 0.061)',
  rhythmA4: 'hsla(240, 91.8%, 94.7%, 0.087)',
  rhythmA5: 'hsla(240, 91.5%, 95.8%, 0.113)',
  rhythmA6: 'hsla(240, 92.0%, 93.8%, 0.148)',
  rhythmA7: 'hsla(240, 94.8%, 95.3%, 0.191)',
  rhythmA8: 'hsla(249, 98.1%, 95.2%, 0.273)',
  rhythmA9: 'hsla(248, 97.6%, 96.2%, 0.416)',
  rhythmA10: 'hsla(248, 95.5%, 96.6%, 0.477)',
  rhythmA11: 'hsla(250, 98.0%, 98.0%, 0.615)',
  rhythmA12: 'hsla(240, 93.9%, 99.6%, 0.931)',
};
