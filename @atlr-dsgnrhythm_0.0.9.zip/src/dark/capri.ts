export const capriDark = {
    capri1: 'hsl(195, 13%, 6%)',
    capri2: 'hsl(191, 29%, 19%)',
    capri3: 'hsl(194, 44%, 32%)',
    capri4: 'hsl(195, 58%, 45%)',
    capri5: 'hsl(197, 100%, 58%)',
    capri6: 'hsl(191, 92%, 67%)',
    capri7: 'hsl(185, 83%, 77%)',
    capri8: 'hsl(178, 74%, 86%)',
    capri9: 'hsl(171, 64%, 96%)',
};
