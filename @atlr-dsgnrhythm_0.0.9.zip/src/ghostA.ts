// Copyright © 2022 Rhythm® Color. All rights reserved.
export const ghostA = {
  ghostA1: 'hsla(0, 0%, 100%, 0)',
  ghostA2: 'hsla(0, 0%, 100%, 0.013)',
  ghostA3: 'hsla(0, 0%, 100%, 0.034)',
  ghostA4: 'hsla(0, 0%, 100%, 0.056)',
  ghostA5: 'hsla(0, 0%, 100%, 0.086)',
  ghostA6: 'hsla(0, 0%, 100%, 0.124)',
  ghostA7: 'hsla(0, 0%, 100%, 0.176)',
  ghostA8: 'hsla(0, 0%, 100%, 0.249)',
  ghostA9: 'hsla(0, 0%, 100%, 0.386)',
  ghostA10: 'hsla(0, 0%, 100%, 0.446)',
  ghostA11: 'hsla(0, 0%, 100%, 0.592)',
  ghostA12: 'hsla(0, 0%, 100%, 0.923)',
};
