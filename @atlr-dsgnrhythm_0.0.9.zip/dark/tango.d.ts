export declare const tangoDark: {
    tango1: string;
    tango2: string;
    tango3: string;
    tango4: string;
    tango5: string;
    tango6: string;
    tango7: string;
    tango8: string;
    tango9: string;
};
