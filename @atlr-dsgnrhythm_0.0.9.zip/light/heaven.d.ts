export declare const heaven: {
    heaven1: string;
    heaven2: string;
    heaven3: string;
    heaven4: string;
    heaven5: string;
    heaven6: string;
    heaven7: string;
    heaven8: string;
    heaven9: string;
};
