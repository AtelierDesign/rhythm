export declare const heavenAlpha: {
    heavenA1: string;
    heavenA2: string;
    heavenA3: string;
    heavenA4: string;
    heavenA5: string;
    heavenA6: string;
    heavenA7: string;
    heavenA8: string;
    heavenA9: string;
};
