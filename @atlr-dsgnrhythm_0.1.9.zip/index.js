'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const rhythmDark = {
    rhythm1: 'hsl(246, 6.0%, 9.0%)',
    rhythm2: 'hsl(240, 5.1%, 11.6%)',
    rhythm3: 'hsl(241, 5.0%, 14.3%)',
    rhythm4: 'hsl(242, 4.9%, 16.5%)',
    rhythm5: 'hsl(243, 4.9%, 18.8%)',
    rhythm6: 'hsl(244, 4.9%, 21.5%)',
    rhythm7: 'hsl(245, 4.9%, 25.4%)',
    rhythm8: 'hsl(247, 4.8%, 32.5%)',
    rhythm9: 'hsl(252, 4.0%, 45.2%)',
    rhythm10: 'hsl(247, 3.4%, 50.7%)',
    rhythm11: 'hsl(253, 4.0%, 63.7%)',
    rhythm12: 'hsl(256, 6.0%, 93.2%)',
};

const razzDark = {
    razz1: 'rgba(59, 0, 15, 1)',
    razz2: 'rgba(108, 0, 31, 1)',
    razz3: 'rgba(157, 0, 49, 1)',
    razz4: 'rgba(205, 0, 70, 1)',
    razz5: 'rgba(227, 11, 93, 1)',
    razz6: 'rgba(254, 60, 126, 1)',
    razz7: 'rgba(255, 120, 162, 1)',
    razz8: 'rgba(255, 180, 202, 1)',
    razz9: 'rgba(255, 240, 244, 1)',
};

const heavenDark = {
    heaven1: 'rgba(35, 34, 59, 1)',
    heaven2: 'rgba(68, 65, 108, 1)',
    heaven3: 'rgba(103, 99, 154, 1)',
    heaven4: 'rgba(140, 136, 197, 1)',
    heaven5: 'rgba(180, 176, 236, 1)',
    heaven6: 'rgba(193, 189, 246, 1)',
    heaven7: 'rgba(208, 205, 253, 1)',
    heaven8: 'rgba(227, 225, 255, 1)',
    heaven9: 'rgba(249, 249, 255, 1)',
};

const yelloDark = {
    yello1: 'rgba(59, 59, 0, 1)',
    yello2: 'rgba(108, 108, 0, 1)',
    yello3: 'rgba(157, 157, 0, 1)',
    yello4: 'rgba(206, 205, 0, 1)',
    yello5: 'rgba(244, 228, 9, 1)',
    yello6: 'rgba(255, 254, 60, 1)',
    yello7: 'rgba(255, 255, 120, 1)',
    yello8: 'rgba(255, 255, 180, 1)',
    yello9: 'rgba(255, 255, 240, 1)',
};

const tangoDark = {
    tango1: 'rgba(94, 0, 29, 1)',
    tango2: 'rgba(135, 11, 26, 1)',
    tango3: 'rgba(175, 37, 29, 1)',
    tango4: 'rgba(215, 86, 54, 1)',
    tango5: 'rgba(254, 139, 85, 1)',
    tango6: 'rgba(255, 160, 109, 1)',
    tango7: 'rgba(255, 185, 143, 1)',
    tango8: 'rgba(255, 214, 186, 1)',
    tango9: 'rgba(255, 246, 240, 1)',
};

const helioDark = {
    helio1: 'rgba(11, 23, 20, 1)',
    helio2: 'rgba(36, 77, 58, 1)',
    helio3: 'rgba(58, 133, 82, 1)',
    helio4: 'rgba(80, 190, 92, 1)',
    helio5: 'rgba(114, 248, 99, 1)',
    helio6: 'rgba(136, 255, 121, 1)',
    helio7: 'rgba(165, 255, 153, 1)',
    helio8: 'rgba(200, 255, 193, 1)',
    helio9: 'rgba(243, 255, 241, 1)',
};

const moonDark = {
    moon1: 'rgba(123, 84, 99, 1)',
    moon2: 'rgba(154, 106, 134, 1)',
    moon3: 'rgba(183, 128, 173, 1)',
    moon4: 'rgba(212, 150, 213, 1)',
    moon5: 'rgba(226, 173, 242, 1)',
    moon6: 'rgba(216, 188, 246, 1)',
    moon7: 'rgba(213, 204, 249, 1)',
    moon8: 'rgba(220, 222, 252, 1)',
    moon9: 'rgba(237, 243, 254, 1)',
};
/*
export const moon = {
    $moon1: 'rgba(237, 243, 254, 1)',
    $moon2: 'rgba(220, 222, 252, 1)',
    $moon3: 'rgba(213, 204, 249, 1)',
    $moon4: 'rgba(216, 188, 246, 1)',
    $moon5: 'rgba(226, 173, 242, 1)',
    $moon6: 'rgba(212, 150, 213, 1)',
    $moon7: 'rgba(183, 128, 173, 1)',
    $moon8: 'rgba(154, 106, 134, 1)',
    $moon9: 'rgba(123, 84, 99, 1)',
};
 */

const capriDark = {
    capri1: 'hsl(195, 13%, 6%)',
    capri2: 'hsl(191, 29%, 19%)',
    capri3: 'hsl(194, 44%, 32%)',
    capri4: 'hsl(195, 58%, 45%)',
    capri5: 'hsl(197, 100%, 58%)',
    capri6: 'hsl(191, 92%, 67%)',
    capri7: 'hsl(185, 83%, 77%)',
    capri8: 'hsl(178, 74%, 86%)',
    capri9: 'hsl(171, 64%, 96%)',
};

const rhythmDarkAlpha = {
    rhythmA1: 'hsla(0, 0%, 0%, 0)',
    rhythmA2: 'hsla(240, 76.7%, 91.2%, 0.031)',
    rhythmA3: 'hsla(240, 86.0%, 95.8%, 0.061)',
    rhythmA4: 'hsla(240, 91.8%, 94.7%, 0.087)',
    rhythmA5: 'hsla(240, 91.5%, 95.8%, 0.113)',
    rhythmA6: 'hsla(240, 92.0%, 93.8%, 0.148)',
    rhythmA7: 'hsla(240, 94.8%, 95.3%, 0.191)',
    rhythmA8: 'hsla(249, 98.1%, 95.2%, 0.273)',
    rhythmA9: 'hsla(248, 97.6%, 96.2%, 0.416)',
    rhythmA10: 'hsla(248, 95.5%, 96.6%, 0.477)',
    rhythmA11: 'hsla(250, 98.0%, 98.0%, 0.615)',
    rhythmA12: 'hsla(240, 93.9%, 99.6%, 0.931)',
};

const razzDarkAlpha = {
    razzA1: 'hsla(344, 100%, 12%, 0.700)',
    razzA2: 'hsla(342, 100%, 21%, 0.416)',
    razzA3: 'hsla(341, 100%, 31%, 0.273)',
    razzA4: 'hsla(339, 100%, 40%, 0.191)',
    razzA5: 'hsla(337, 91%, 47%, 0.148)',
    razzA6: 'hsla(339, 99%, 62%, 0.113)',
    razzA7: 'hsla(341, 100%, 74%, 0.087)',
    razzA8: 'hsla(342, 100%, 85%, 0.061)',
    razzA9: 'hsla(344, 100%, 97%, 0.031)',
};

const rhythm = {
    rhythm1: 'hsl(300, 20.0%, 99.0%)',
    rhythm2: 'hsl(300, 7.7%, 97.5%)',
    rhythm3: 'hsl(294, 5.5%, 95.3%)',
    rhythm4: 'hsl(289, 4.7%, 93.3%)',
    rhythm5: 'hsl(255, 3.7%, 78.8%)',
    rhythm6: 'hsl(252, 4.0%, 57.3%)',
    rhythm7: 'hsl(253, 3.5%, 53.5%)',
    rhythm8: 'hsl(252, 4.0%, 44.8%)',
    rhythm9: 'hsl(260, 25.0%, 11.0%)',
};

const razz = {
    razz1: 'rgba(255, 240, 244, 1)',
    razz2: 'rgba(255, 180, 202, 1)',
    razz3: 'rgba(255, 120, 162, 1)',
    razz4: 'rgba(254, 60, 126, 1)',
    razz5: 'rgba(227, 11, 93, 1)',
    razz6: 'rgba(205, 0, 70, 1)',
    razz7: 'rgba(157, 0, 49, 1)',
    razz8: 'rgba(108, 0, 31, 1)',
    razz9: 'rgba(59, 0, 15, 1)',
};

const heaven = {
    heaven1: 'rgba(249, 249, 255, 1)',
    heaven2: 'rgba(227, 225, 255, 1)',
    heaven3: 'rgba(208, 205, 253, 1)',
    heaven4: 'rgba(193, 189, 246, 1)',
    heaven5: 'rgba(180, 176, 236, 1)',
    heaven6: 'rgba(140, 136, 197, 1)',
    heaven7: 'rgba(103, 99, 154, 1)',
    heaven8: 'rgba(68, 65, 108, 1)',
    heaven9: 'rgba(35, 34, 59, 1)',
};

const yello = {
    yello1: 'rgba(255, 255, 240, 1)',
    yello2: 'rgba(255, 255, 180, 1)',
    yello3: 'rgba(255, 255, 120, 1)',
    yello4: 'rgba(255, 254, 60, 1)',
    yello5: 'rgba(244, 228, 9, 1)',
    yello6: 'rgba(206, 205, 0, 1)',
    yello7: 'rgba(157, 157, 0, 1)',
    yello8: 'rgba(108, 108, 0, 1)',
    yello9: 'rgba(59, 59, 0, 1)',
};

const tango = {
    tango1: 'rgba(255, 246, 240, 1)',
    tango2: 'rgba(255, 214, 186, 1)',
    tango3: 'rgba(255, 185, 143, 1)',
    tango4: 'rgba(255, 160, 109, 1)',
    tango5: 'rgba(254, 139, 85, 1)',
    tango6: 'rgba(215, 86, 54, 1)',
    tango7: 'rgba(175, 37, 29, 1)',
    tango8: 'rgba(135, 11, 26, 1)',
    tango9: 'rgba(94, 0, 29, 1)',
};

const helio = {
    helio1: 'rgba(243, 255, 241, 1)',
    helio2: 'rgba(200, 255, 193, 1)',
    helio3: 'rgba(165, 255, 153, 1)',
    helio4: 'rgba(136, 255, 121, 1)',
    helio5: 'rgba(114, 248, 99, 1)',
    helio6: 'rgba(80, 190, 92, 1)',
    helio7: 'rgba(58, 133, 82, 1)',
    helio8: 'rgba(36, 77, 58, 1)',
    helio9: 'rgba(11, 23, 20, 1)',
};

const moon = {
    moon1: 'rgba(237, 243, 254, 1)',
    moon2: 'rgba(220, 222, 252, 1)',
    moon3: 'rgba(213, 204, 249, 1)',
    moon4: 'rgba(216, 188, 246, 1)',
    moon5: 'rgba(226, 173, 242, 1)',
    moon6: 'rgba(212, 150, 213, 1)',
    moon7: 'rgba(183, 128, 173, 1)',
    moon8: 'rgba(154, 106, 134, 1)',
    moon9: 'rgba(123, 84, 99, 1)',
};

const capri = {
    capri1: 'hsl(171, 64%, 96%)',
    capri2: 'hsl(178, 74%, 86%)',
    capri3: 'hsl(185, 83%, 77%)',
    capri4: 'hsl(191, 92%, 67%)',
    capri5: 'hsl(197, 100%, 58%)',
    capri6: 'hsl(195, 58%, 45%)',
    capri7: 'hsl(194, 44%, 32%)',
    capri8: 'hsl(191, 29%, 19%)',
    capri9: 'hsl(195, 13%, 6%)',
};

const rhythmA = {
    rhythmA1: 'hsla(300, 89.3%, 18.3%, 0.012)',
    rhythmA2: 'hsla(300, 78.1%, 9.0%, 0.028)',
    rhythmA3: 'hsla(300, 99.5%, 7.7%, 0.051)',
    rhythmA4: 'hsla(270, 90.5%, 6.1%, 0.071)',
    rhythmA5: 'hsla(270, 83.0%, 5.2%, 0.091)',
    rhythmA6: 'hsla(300, 93.5%, 3.7%, 0.114)',
    rhythmA7: 'hsla(270, 82.6%, 3.3%, 0.142)',
    rhythmA8: 'hsla(255, 95.2%, 3.7%, 0.220)',
    rhythmA9: 'hsla(255, 94.8%, 3.7%, 0.444)',
    rhythmA10: 'hsla(253, 96.5%, 3.8%, 0.483)',
    rhythmA11: 'hsla(247, 97.9%, 3.2%, 0.569)',
    rhythmA12: 'hsla(261, 98.7%, 3.0%, 0.918)',
};

const razzAlpha = {
    razzA1: 'hsla(344, 100%, 97%, 0.031)',
    razzA2: 'hsla(342, 100%, 85%, 0.061)',
    razzA3: 'hsla(341, 100%, 74%, 0.087)',
    razzA4: 'hsla(339, 99%, 62%, 0.113)',
    razzA5: 'hsla(337, 91%, 47%, 0.148)',
    razzA6: 'hsla(339, 100%, 40%, 0.191)',
    razzA7: 'hsla(341, 100%, 31%, 0.273)',
    razzA8: 'hsla(342, 100%, 21%, 0.416)',
    razzA9: 'hsla(344, 100%, 12%, 0.700)',
};

const heavenAlpha = {
    heavenA1: 'hsla(240, 100%, 99%, 0.012)',
    heavenA2: 'hsla(244, 100%, 94%, 0.028)',
    heavenA3: 'hsla(243, 92%, 90%, 0.051)',
    heavenA4: 'hsla(244, 76%, 85%, 0.071)',
    heavenA5: 'hsla(244, 61%, 81%, 0.091)',
    heavenA6: 'hsla(243, 35%, 65%, 0.114)',
    heavenA7: 'hsla(244, 22%, 50%, 0.142)',
    heavenA8: 'hsla(244, 25%, 34%, 0.444)',
    heavenA9: 'hsla(242, 27%, 18%, 0.700)',
};

const yelloAlpha = {
    yelloA1: 'hsla(60, 100%, 97%, 0.031)',
    yelloA2: 'hsla(60, 100%, 85%, 0.061)',
    yelloA3: 'hsla(60, 100%, 74%, 0.087)',
    yelloA4: 'hsla(59, 100%, 62%, 0.113)',
    yelloA5: 'hsla(55, 93%, 50%, 0.148)',
    yelloA6: 'hsla(59, 100%, 40%, 0.191)',
    yelloA7: 'hsla(60, 100%, 31%, 0.273)',
    yelloA8: 'hsla(60, 100%, 21%, 0.416)',
    yelloA9: 'hsla(60, 100%, 12%, 0.700)',
};

const tangoAlpha = {
    tangoA1: 'hsla(24, 100%, 97%, 0.031)',
    tangoA2: 'hsla(24, 100%, 87%, 0.061)',
    tangoA3: 'hsla(22, 100%, 78%, 0.087)',
    tangoA4: 'hsla(20, 100%, 71%, 0.113)',
    tangoA5: 'hsla(19, 99%, 67%, 0.148)',
    tangoA6: 'hsla(11, 67%, 53%, 0.191)',
    tangoA7: 'hsla(3, 72%, 40%, 0.273)',
    tangoA8: 'hsla(352, 85%, 29%, 0.416)',
    tangoA9: 'hsla(341, 100%, 18%, 0.700)',
};

const helioAlpha = {
    helioA1: 'hsla(111, 100%, 97%, 0.031)',
    helioA2: 'hsla(113, 100%, 88%, 0.061)',
    helioA3: 'hsla(112, 100%, 80%, 0.087)',
    helioA4: 'hsla(113, 100%, 74%, 0.113)',
    helioA5: 'hsla(113, 91%, 68%, 0.148)',
    helioA6: 'hsla(126, 46%, 53%, 0.191)',
    helioA7: 'hsla(139, 39%, 38%, 0.273)',
    helioA8: 'hsla(152, 36%, 22%, 0.416)',
    helioA9: 'hsla(165, 35%, 7%, 0.700)',
};

const moonAlpha = {
    moonA1: 'hsla(218, 90%, 96%, 0.012)',
    moonA2: 'hsla(236, 84%, 93%, 0.028)',
    moonA3: 'hsla(252, 79%, 89%, 0.051)',
    moonA4: 'hsla(268, 76%, 85%, 0.071)',
    moonA5: 'hsla(286, 73%, 81%, 0.091)',
    moonA6: 'hsla(299, 43%, 71%, 0.114)',
    moonA7: 'hsla(310, 28%, 61%, 0.142)',
    moonA8: 'hsla(325, 19%, 51%, 0.444)',
    moonA9: 'hsla(336, 19%, 41%, 0.700)',
};

const capriAlpha = {
    capriA1: 'hsla(171, 64%, 96%, 0.012)',
    capriA2: 'hsla(178, 74%, 86%, 0.028)',
    capriA3: 'hsla(185, 83%, 77%, 0.051)',
    capriA4: 'hsla(191, 92%, 67%, 0.071)',
    capriA5: 'hsla(197, 100%, 58%, 0.091)',
    capriA6: 'hsla(195, 58%, 45%, 0.114)',
    capriA7: 'hsla(194, 44%, 32%, 0.142)',
    capriA8: 'hsla(191, 29%, 19%, 0.444)',
    capriA9: 'hsla(195, 13%, 6%, 0.700)',
};

// Copyright © 2022 Rhythm® Color. All rights reserved.
const dawnA = {
    dawnA1: 'hsla(0, 0%, 0%, 0.012)',
    dawnA2: 'hsla(0, 0%, 0%, 0.027)',
    dawnA3: 'hsla(0, 0%, 0%, 0.047)',
    dawnA4: 'hsla(0, 0%, 0%, 0.071)',
    dawnA5: 'hsla(0, 0%, 0%, 0.090)',
    dawnA6: 'hsla(0, 0%, 0%, 0.114)',
    dawnA7: 'hsla(0, 0%, 0%, 0.141)',
    dawnA8: 'hsla(0, 0%, 0%, 0.220)',
    dawnA9: 'hsla(0, 0%, 0%, 0.439)',
    dawnA10: 'hsla(0, 0%, 0%, 0.478)',
    dawnA11: 'hsla(0, 0%, 0%, 0.565)',
    dawnA12: 'hsla(0, 0%, 0%, 0.910)',
};

// Copyright © 2022 Rhythm® Color. All rights reserved.
const ghostA = {
    ghostA1: 'hsla(0, 0%, 100%, 0)',
    ghostA2: 'hsla(0, 0%, 100%, 0.013)',
    ghostA3: 'hsla(0, 0%, 100%, 0.034)',
    ghostA4: 'hsla(0, 0%, 100%, 0.056)',
    ghostA5: 'hsla(0, 0%, 100%, 0.086)',
    ghostA6: 'hsla(0, 0%, 100%, 0.124)',
    ghostA7: 'hsla(0, 0%, 100%, 0.176)',
    ghostA8: 'hsla(0, 0%, 100%, 0.249)',
    ghostA9: 'hsla(0, 0%, 100%, 0.386)',
    ghostA10: 'hsla(0, 0%, 100%, 0.446)',
    ghostA11: 'hsla(0, 0%, 100%, 0.592)',
    ghostA12: 'hsla(0, 0%, 100%, 0.923)',
};

exports.capri = capri;
exports.capriAlpha = capriAlpha;
exports.capriDark = capriDark;
exports.dawnA = dawnA;
exports.ghostA = ghostA;
exports.heaven = heaven;
exports.heavenAlpha = heavenAlpha;
exports.heavenDark = heavenDark;
exports.helio = helio;
exports.helioAlpha = helioAlpha;
exports.helioDark = helioDark;
exports.moon = moon;
exports.moonAlpha = moonAlpha;
exports.moonDark = moonDark;
exports.razz = razz;
exports.razzAlpha = razzAlpha;
exports.razzDark = razzDark;
exports.razzDarkAlpha = razzDarkAlpha;
exports.rhythm = rhythm;
exports.rhythmA = rhythmA;
exports.rhythmDark = rhythmDark;
exports.rhythmDarkAlpha = rhythmDarkAlpha;
exports.tango = tango;
exports.tangoAlpha = tangoAlpha;
exports.tangoDark = tangoDark;
exports.yello = yello;
exports.yelloAlpha = yelloAlpha;
exports.yelloDark = yelloDark;
