export declare const moon: {
    moon1: string;
    moon2: string;
    moon3: string;
    moon4: string;
    moon5: string;
    moon6: string;
    moon7: string;
    moon8: string;
    moon9: string;
};
