export declare const capri: {
    capri1: string;
    capri2: string;
    capri3: string;
    capri4: string;
    capri5: string;
    capri6: string;
    capri7: string;
    capri8: string;
    capri9: string;
};
