export declare const helio: {
    helio1: string;
    helio2: string;
    helio3: string;
    helio4: string;
    helio5: string;
    helio6: string;
    helio7: string;
    helio8: string;
    helio9: string;
};
