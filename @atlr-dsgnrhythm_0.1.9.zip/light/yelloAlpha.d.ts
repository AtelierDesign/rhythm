export declare const yelloAlpha: {
    yelloA1: string;
    yelloA2: string;
    yelloA3: string;
    yelloA4: string;
    yelloA5: string;
    yelloA6: string;
    yelloA7: string;
    yelloA8: string;
    yelloA9: string;
};
