export declare const moonAlpha: {
    moonA1: string;
    moonA2: string;
    moonA3: string;
    moonA4: string;
    moonA5: string;
    moonA6: string;
    moonA7: string;
    moonA8: string;
    moonA9: string;
};
