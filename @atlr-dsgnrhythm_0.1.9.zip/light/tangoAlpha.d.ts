export declare const tangoAlpha: {
    tangoA1: string;
    tangoA2: string;
    tangoA3: string;
    tangoA4: string;
    tangoA5: string;
    tangoA6: string;
    tangoA7: string;
    tangoA8: string;
    tangoA9: string;
};
