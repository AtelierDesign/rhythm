export declare const razzAlpha: {
    razzA1: string;
    razzA2: string;
    razzA3: string;
    razzA4: string;
    razzA5: string;
    razzA6: string;
    razzA7: string;
    razzA8: string;
    razzA9: string;
};
