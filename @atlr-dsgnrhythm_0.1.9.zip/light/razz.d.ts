export declare const razz: {
    razz1: string;
    razz2: string;
    razz3: string;
    razz4: string;
    razz5: string;
    razz6: string;
    razz7: string;
    razz8: string;
    razz9: string;
};
