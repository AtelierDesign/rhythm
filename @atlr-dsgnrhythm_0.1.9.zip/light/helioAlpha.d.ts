export declare const helioAlpha: {
    helioA1: string;
    helioA2: string;
    helioA3: string;
    helioA4: string;
    helioA5: string;
    helioA6: string;
    helioA7: string;
    helioA8: string;
    helioA9: string;
};
