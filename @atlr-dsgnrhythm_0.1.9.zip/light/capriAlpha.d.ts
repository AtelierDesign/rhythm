export declare const capriAlpha: {
    capriA1: string;
    capriA2: string;
    capriA3: string;
    capriA4: string;
    capriA5: string;
    capriA6: string;
    capriA7: string;
    capriA8: string;
    capriA9: string;
};
