export const yelloDark = {
    yello1: 'rgba(59, 59, 0, 1)',
    yello2: 'rgba(108, 108, 0, 1)',
    yello3: 'rgba(157, 157, 0, 1)',
    yello4: 'rgba(206, 205, 0, 1)',
    yello5: 'rgba(244, 228, 9, 1)',
    yello6: 'rgba(255, 254, 60, 1)',
    yello7: 'rgba(255, 255, 120, 1)',
    yello8: 'rgba(255, 255, 180, 1)',
    yello9: 'rgba(255, 255, 240, 1)',
};
