export const rhythmDark = {
  rhythm1: 'hsl(246, 6.0%, 9.0%)',
  rhythm2: 'hsl(240, 5.1%, 11.6%)',
  rhythm3: 'hsl(241, 5.0%, 14.3%)',
  rhythm4: 'hsl(242, 4.9%, 16.5%)',
  rhythm5: 'hsl(243, 4.9%, 18.8%)',
  rhythm6: 'hsl(244, 4.9%, 21.5%)',
  rhythm7: 'hsl(245, 4.9%, 25.4%)',
  rhythm8: 'hsl(247, 4.8%, 32.5%)',
  rhythm9: 'hsl(252, 4.0%, 45.2%)',
  rhythm10: 'hsl(247, 3.4%, 50.7%)',
  rhythm11: 'hsl(253, 4.0%, 63.7%)',
  rhythm12: 'hsl(256, 6.0%, 93.2%)',
};
