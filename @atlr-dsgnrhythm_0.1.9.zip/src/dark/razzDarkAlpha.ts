export const razzDarkAlpha = {
    razzA1: 'hsla(344, 100%, 12%, 0.700)',
    razzA2: 'hsla(342, 100%, 21%, 0.416)',
    razzA3: 'hsla(341, 100%, 31%, 0.273)',
    razzA4: 'hsla(339, 100%, 40%, 0.191)',
    razzA5: 'hsla(337, 91%, 47%, 0.148)',
    razzA6: 'hsla(339, 99%, 62%, 0.113)',
    razzA7: 'hsla(341, 100%, 74%, 0.087)',
    razzA8: 'hsla(342, 100%, 85%, 0.061)',
    razzA9: 'hsla(344, 100%, 97%, 0.031)',
};
