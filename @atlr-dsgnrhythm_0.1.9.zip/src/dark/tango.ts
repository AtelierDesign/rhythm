export const tangoDark = {
    tango1: 'rgba(94, 0, 29, 1)',
    tango2: 'rgba(135, 11, 26, 1)',
    tango3: 'rgba(175, 37, 29, 1)',
    tango4: 'rgba(215, 86, 54, 1)',
    tango5: 'rgba(254, 139, 85, 1)',
    tango6: 'rgba(255, 160, 109, 1)',
    tango7: 'rgba(255, 185, 143, 1)',
    tango8: 'rgba(255, 214, 186, 1)',
    tango9: 'rgba(255, 246, 240, 1)',
};
