export const razzDark = {
    razz1: 'rgba(59, 0, 15, 1)',
    razz2: 'rgba(108, 0, 31, 1)',
    razz3: 'rgba(157, 0, 49, 1)',
    razz4: 'rgba(205, 0, 70, 1)',
    razz5: 'rgba(227, 11, 93, 1)',
    razz6: 'rgba(254, 60, 126, 1)',
    razz7: 'rgba(255, 120, 162, 1)',
    razz8: 'rgba(255, 180, 202, 1)',
    razz9: 'rgba(255, 240, 244, 1)',
};
