export const capriAlpha = {
    capriA1: 'hsla(171, 64%, 96%, 0.012)',
    capriA2: 'hsla(178, 74%, 86%, 0.028)',
    capriA3: 'hsla(185, 83%, 77%, 0.051)',
    capriA4: 'hsla(191, 92%, 67%, 0.071)',
    capriA5: 'hsla(197, 100%, 58%, 0.091)',
    capriA6: 'hsla(195, 58%, 45%, 0.114)',
    capriA7: 'hsla(194, 44%, 32%, 0.142)',
    capriA8: 'hsla(191, 29%, 19%, 0.444)',
    capriA9: 'hsla(195, 13%, 6%, 0.700)',
};
