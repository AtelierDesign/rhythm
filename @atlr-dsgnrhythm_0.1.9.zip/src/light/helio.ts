export const helio = {
    helio1: 'rgba(243, 255, 241, 1)',
    helio2: 'rgba(200, 255, 193, 1)',
    helio3: 'rgba(165, 255, 153, 1)',
    helio4: 'rgba(136, 255, 121, 1)',
    helio5: 'rgba(114, 248, 99, 1)',
    helio6: 'rgba(80, 190, 92, 1)',
    helio7: 'rgba(58, 133, 82, 1)',
    helio8: 'rgba(36, 77, 58, 1)',
    helio9: 'rgba(11, 23, 20, 1)',
};
