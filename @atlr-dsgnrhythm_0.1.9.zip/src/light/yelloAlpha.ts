export const yelloAlpha = {
    yelloA1: 'hsla(60, 100%, 97%, 0.031)',
    yelloA2: 'hsla(60, 100%, 85%, 0.061)',
    yelloA3: 'hsla(60, 100%, 74%, 0.087)',
    yelloA4: 'hsla(59, 100%, 62%, 0.113)',
    yelloA5: 'hsla(55, 93%, 50%, 0.148)',
    yelloA6: 'hsla(59, 100%, 40%, 0.191)',
    yelloA7: 'hsla(60, 100%, 31%, 0.273)',
    yelloA8: 'hsla(60, 100%, 21%, 0.416)',
    yelloA9: 'hsla(60, 100%, 12%, 0.700)',
};
