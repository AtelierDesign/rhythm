export const heavenAlpha = {
    heavenA1: 'hsla(240, 100%, 99%, 0.012)',
    heavenA2: 'hsla(244, 100%, 94%, 0.028)',
    heavenA3: 'hsla(243, 92%, 90%, 0.051)',
    heavenA4: 'hsla(244, 76%, 85%, 0.071)',
    heavenA5: 'hsla(244, 61%, 81%, 0.091)',
    heavenA6: 'hsla(243, 35%, 65%, 0.114)',
    heavenA7: 'hsla(244, 22%, 50%, 0.142)',
    heavenA8: 'hsla(244, 25%, 34%, 0.444)',
    heavenA9: 'hsla(242, 27%, 18%, 0.700)',
};
