export declare const rhythmDark: {
    rhythm1: string;
    rhythm2: string;
    rhythm3: string;
    rhythm4: string;
    rhythm5: string;
    rhythm6: string;
    rhythm7: string;
    rhythm8: string;
    rhythm9: string;
    rhythm10: string;
    rhythm11: string;
    rhythm12: string;
};
