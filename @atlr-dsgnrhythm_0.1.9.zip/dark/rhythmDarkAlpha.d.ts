export declare const rhythmDarkAlpha: {
    rhythmA1: string;
    rhythmA2: string;
    rhythmA3: string;
    rhythmA4: string;
    rhythmA5: string;
    rhythmA6: string;
    rhythmA7: string;
    rhythmA8: string;
    rhythmA9: string;
    rhythmA10: string;
    rhythmA11: string;
    rhythmA12: string;
};
