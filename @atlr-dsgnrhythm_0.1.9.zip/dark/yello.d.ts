export declare const yelloDark: {
    yello1: string;
    yello2: string;
    yello3: string;
    yello4: string;
    yello5: string;
    yello6: string;
    yello7: string;
    yello8: string;
    yello9: string;
};
